int initXPCOM();
