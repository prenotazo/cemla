#ifndef _STDINT_H_
#define _STDINT_H_

#include <windows.h>

typedef UINT32 uint32_t;

#endif // _STDINT_H_
